﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrimerPrograma
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> compra = new List<string>();

            compra.Add("Tomates");
            compra.Add("Patatas");
            compra.Add("Caramelos");

            //  compra.Insert(0, "Leche");

            for (int i = 0; i < compra.Count(); i++)
            {
                Console.WriteLine(compra[i]);
            }

            Console.ReadKey();
        }
    }
}