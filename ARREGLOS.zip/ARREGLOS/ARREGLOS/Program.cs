﻿using System;
using System.Collections.Generic;

namespace EJEMPLOS
{
    class Ejemplo_Arreglos
    {
        static void Main(string[] args)

        /* definir 5 variables para tener 
           sueldos almacenados en memoria. */

        {
            double[] Sueldos;
            Sueldos = new double[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese el sueldo del empleado" + (i + 1) + ":");
                Sueldos[i] = double.Parse(Console.ReadLine());
            }
            Mostrar(Sueldos);
            Console.ReadKey();
        }
        static void Mostrar(double[] Sueldos)
        {
            Console.WriteLine("Los sueldos ingresados son: ");
            for (int i = 0; i < 5; i++)
            {
                Console.Write("\t" + Sueldos[i]);
            }
        }
    }
}