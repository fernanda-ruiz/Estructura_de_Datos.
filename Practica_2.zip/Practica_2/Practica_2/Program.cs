﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Hacer una aplicación en C# de consola, 
            donde se solicite ingresar nombre de 10 personas, 
            al terminar de ingresar esas 10 personas, 
            debe de mostrar una lista con los nombres ingresados.
            */
            string[] nombrePersonas = new string[10];
            for (int i = 0; i < nombrePersonas.Length; i++)
            {
                Console.Write($"Escriba aquí el nombre de la persona { i + 1 } :");
                nombrePersonas[i] = Console.ReadLine();
            }
            for (int i = 0; i < nombrePersonas.Length; i++)
            {
                Console.WriteLine("El nombre de persona " + (i + 1) + " es: " + nombrePersonas[i]);
            }
            Console.ReadLine();
            //Hecho por Fernanda Ruiz Hirales
        }
    }
}